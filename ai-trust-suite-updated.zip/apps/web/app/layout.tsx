import "./globals.css";
export const metadata={title:"AI Trust Suite",description:"Test, verify, compare and secure AI systems."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
