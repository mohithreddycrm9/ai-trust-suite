"use client";
import {useEffect,useState} from "react";
import {useParams} from "next/navigation";
import Shell from "../../components/Shell";
const API=process.env.NEXT_PUBLIC_API_URL||"http://localhost:8000/api/v1";
const dims=["accuracy","honesty","safety","relevance","clarity","instruction_following"];
export default function Report(){const {id}=useParams<{id:string}>();const [r,setR]=useState<any>(),[e,setE]=useState("");useEffect(()=>{if(!id)return;fetch(API+`/reports/${id}`,{credentials:"include"}).then(async x=>{const d=await x.json();if(!x.ok)throw Error(d?.error?.message||"Report unavailable");setR(d)}).catch(x=>setE(x.message))},[id]);return <Shell><div className="content"><div className="eyebrow">Arena report</div><div className="h1">Evaluation report</div>{e&&<div className="card error">{e}</div>}{r&&<><div className="arena"><Result title="Model A" response={r.model_a_response} scores={r.model_a.scores}/><Result title="Model B" response={r.model_b_response} scores={r.model_b.scores}/></div><div className="card"><h3>Judge rationale</h3><p className="muted">{r.model_a.scores.rationale}</p><p className="muted">{r.model_b.scores.rationale}</p></div></>}</div></Shell>}
function Result({title,response,scores}:any){return <div className="card"><h3>{title}</h3><div className="response">{response}</div><div className="scores">{dims.map(d=><div key={d}><span>{d.replace("_"," ")}</span><b>{scores[d]}/10</b></div>)}</div></div>}
