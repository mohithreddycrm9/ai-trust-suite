"use client";
import Link from "next/link";
import {usePathname} from "next/navigation";
const items=[['Overview','/'],['Arena','/arena'],['Verify','/verify'],['Test Lab','/test-lab'],['Secure','/secure'],['Knowledge','/knowledge'],['Models','/models'],['Reports','/reports']];
export default function Shell({children}:{children:React.ReactNode}){const path=usePathname();return <div className="app"><aside className="side"><div className="brand">◈ AI TRUST SUITE</div>{items.map(([n,u])=><Link key={n} href={u} className={'nav '+(path===u||path.startsWith(u+'/')?'active':'')}>{n}</Link>)}</aside><main className="main"><header className="top"><span>Trust workspace</span><span className="status">● Protected</span></header>{children}</main></div>}
