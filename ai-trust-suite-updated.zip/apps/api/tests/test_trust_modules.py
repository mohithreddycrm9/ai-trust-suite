from app.evaluation.text import chunk_text, embed_text, cosine
from app.evaluation.verify import extract_claims
from app.evaluation.secure import ATTACKS
from app.pricing import estimate_cost

def test_knowledge_chunking_and_embedding():
    chunks=chunk_text("A"*2500,size=1000,overlap=100)
    assert len(chunks)>=3
    a=embed_text("postgres vector database")
    b=embed_text("postgres vector database")
    assert len(a)==64 and cosine(a,b)>0.99

def test_verify_claim_extraction():
    claims=extract_claims("The service stores data in Postgres. It supports pgvector for similarity search.\nThis is short.")
    assert len(claims)==2

def test_secure_suite_has_multiple_attack_classes():
    assert len(ATTACKS)==3
    assert {x[0] for x in ATTACKS}=={"indirect_prompt_injection","tool_output_injection","data_exfiltration"}

def test_known_pricing_and_unknown_handling():
    cost,status=estimate_cost("openai","gpt-5.6-luna",1_000_000,1_000_000)
    assert status=="estimated" and cost==1.4
    assert estimate_cost("openai","not-a-real-model",100,50)==(None,"unknown")
