from app.auth import ROLES

def test_viewer_cannot_manage_models():
    assert ROLES["Viewer"] < ROLES["Member"]

def test_member_cannot_manage_models():
    assert ROLES["Member"] < ROLES["Admin"]

def test_admin_can_manage_models():
    assert ROLES["Admin"] >= ROLES["Admin"]
