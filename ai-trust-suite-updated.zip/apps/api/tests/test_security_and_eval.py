import json, uuid, pytest
from cryptography.fernet import Fernet
from app.security import encrypt_secret,decrypt_secret,hash_password
from app.evaluation.parser import parse_judge_output
from app.evaluation.schemas import BlindJudgeResult
from app.ssrf import validate_base_url
from app.pricing import estimate_cost
from app.errors import JudgeOutputError

@pytest.mark.asyncio
async def test_encryption_round_trip():
    value="super-secret-key"
    assert decrypt_secret(encrypt_secret(value))==value

def test_key_never_returned():
    payload={"id":"1","provider":"openai","model":"x","name":"x"}
    assert "api_key" not in payload and "encrypted_api_key" not in payload

def test_judge_json_parsing_code_fence_and_validation():
    body={"response_a":{"accuracy":9,"honesty":8,"safety":10,"relevance":9,"clarity":8,"instruction_following":7,"rationale":"good"},"response_b":{"accuracy":6,"honesty":7,"safety":9,"relevance":6,"clarity":7,"instruction_following":8,"rationale":"mixed"}}
    parsed=parse_judge_output("```json\n"+json.dumps(body)+"\n```")
    assert parsed.response_a.accuracy==9 and parsed.response_b.instruction_following==8

def test_judge_json_invalid_is_error():
    with pytest.raises(JudgeOutputError): parse_judge_output('{"response_a":{"accuracy":99}}')

@pytest.mark.asyncio
async def test_ssrf_blocks_private():
    with pytest.raises(Exception): await validate_base_url("http://127.0.0.1:11434","openai")

@pytest.mark.asyncio
async def test_ollama_allowlist_exception():
    await validate_base_url("http://127.0.0.1:11434","ollama")

def test_unknown_cost_is_not_invented():
    assert estimate_cost("openai","unknown-model",100,50)==(None,"unknown")
