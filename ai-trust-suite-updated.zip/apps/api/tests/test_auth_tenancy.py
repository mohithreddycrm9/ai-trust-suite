import pytest
from sqlalchemy.ext.asyncio import create_async_engine,async_sessionmaker
from app.db import Base
from app.models import User,Organization,Membership,ModelConnection
from app.security import hash_password
from app.auth import ROLES
from uuid import uuid4

@pytest.mark.asyncio
async def test_tenant_isolation_and_roles():
    engine=create_async_engine("sqlite+aiosqlite:///:memory:")
    Session=async_sessionmaker(engine,expire_on_commit=False)
    async with engine.begin() as c: await c.run_sync(Base.metadata.create_all)
    async with Session() as db:
        o1,o2=Organization(name="one"),Organization(name="two");u=User(email="u@example.com",password_hash=hash_password("password-password"));db.add_all([o1,o2,u]);await db.flush();db.add_all([Membership(user_id=u.id,organization_id=o1.id,role="Member"),Membership(user_id=u.id,organization_id=o2.id,role="Viewer")]);m1=ModelConnection(organization_id=o1.id,name="a",provider="ollama",model="m");m2=ModelConnection(organization_id=o2.id,name="b",provider="ollama",model="m");db.add_all([m1,m2]);await db.commit()
        from sqlalchemy import select
        own=(await db.execute(select(ModelConnection).where(ModelConnection.organization_id==o1.id))).scalars().all()
        assert len(own)==1 and own[0].id==m1.id and own[0].id!=m2.id
        assert ROLES["Owner"]>ROLES["Admin"]>ROLES["Member"]>ROLES["Viewer"]
    await engine.dispose()
