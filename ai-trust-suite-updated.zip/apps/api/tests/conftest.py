import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import os
os.environ["DATABASE_URL"]="sqlite+aiosqlite:///./test.db"
os.environ["ENCRYPTION_KEY"]="Z3hYQ2hXc0F6Qm5xVjN2cGJ4VjZqZ2h3aVd0d2JpQm8="
os.environ["JWT_SECRET"]="test-secret-that-is-long-enough"
os.environ["CORS_ORIGINS"]="http://testserver"
os.environ["COOKIE_SECURE"]="false"
os.environ["OLLAMA_ALLOWED_BASE_URLS"]="http://127.0.0.1:11434"
