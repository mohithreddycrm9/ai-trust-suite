import httpx, pytest
from unittest.mock import patch
from app.providers.openai import OpenAIProvider
from app.providers.anthropic import AnthropicProvider
from app.providers.gemini import GeminiProvider
from app.providers.ollama import OllamaProvider
from app.providers.base import GenerationRequest

@pytest.mark.asyncio
@pytest.mark.parametrize("provider_cls,body,expected",[
(OpenAIProvider,{"choices":[{"message":{"content":"ok"}}],"usage":{"prompt_tokens":3,"completion_tokens":4}},"ok"),
(AnthropicProvider,{"content":[{"text":"ok"}],"usage":{"input_tokens":3,"output_tokens":4}},"ok"),
(GeminiProvider,{"candidates":[{"content":{"parts":[{"text":"ok"}]}}],"usageMetadata":{"promptTokenCount":3,"candidatesTokenCount":4}},"ok"),
(OllamaProvider,{"message":{"content":"ok"},"prompt_eval_count":3,"eval_count":4},"ok")])
async def test_provider_usage_normalization(provider_cls,body,expected):
    class FakeResponse:
        status_code=200
        def json(self): return body
        def raise_for_status(self): pass
    async def fake_post(*a,**k): return FakeResponse()
    with patch.object(httpx.AsyncClient,"post",new=fake_post):
        if provider_cls is OpenAIProvider:p=provider_cls("k","m")
        elif provider_cls is AnthropicProvider:p=provider_cls("k","m")
        elif provider_cls is GeminiProvider:p=provider_cls("k","m")
        else:p=provider_cls("m","http://example.com")
        r=await p.generate(GenerationRequest("hi"))
        assert r.text==expected and r.usage.input_tokens==3 and r.usage.output_tokens==4
