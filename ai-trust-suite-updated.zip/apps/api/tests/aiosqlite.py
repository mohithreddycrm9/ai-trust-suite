import asyncio, sqlite3, threading
sqlite_version=sqlite3.sqlite_version
sqlite_version_info=sqlite3.sqlite_version_info
Error=sqlite3.Error; DatabaseError=sqlite3.DatabaseError; IntegrityError=sqlite3.IntegrityError; NotSupportedError=sqlite3.NotSupportedError; OperationalError=sqlite3.OperationalError; ProgrammingError=sqlite3.ProgrammingError
PARSE_COLNAMES=sqlite3.PARSE_COLNAMES; PARSE_DECLTYPES=sqlite3.PARSE_DECLTYPES; Binary=sqlite3.Binary

class Cursor:
    def __init__(self,c): self._c=c
    async def execute(self,sql,params=()):
        self._c.execute(sql,params);return self
    async def executemany(self,sql,params): self._c.executemany(sql,params);return self
    async def fetchall(self): return self._c.fetchall()
    async def fetchone(self): return self._c.fetchone()
    async def fetchmany(self,size=None): return self._c.fetchmany(size or 1)
    async def close(self): self._c.close()
    @property
    def description(self): return self._c.description
    @property
    def lastrowid(self): return self._c.lastrowid
    @property
    def rowcount(self): return self._c.rowcount

class Connection:
    def __init__(self,path,**kw):
        self._conn=sqlite3.connect(path,check_same_thread=False,**{k:v for k,v in kw.items() if k in {'detect_types','isolation_level'}})
        self._thread=threading.Thread();self._thread.daemon=True
    def __await__(self):
        async def done(): return self
        return done().__await__()
    @property
    def isolation_level(self): return self._conn.isolation_level
    @isolation_level.setter
    def isolation_level(self,v): self._conn.isolation_level=v
    async def cursor(self): return Cursor(self._conn.cursor())
    async def execute(self,sql,params=()):
        c=await self.cursor();await c.execute(sql,params);return c
    async def commit(self): self._conn.commit()
    async def rollback(self): self._conn.rollback()
    async def close(self): self._conn.close()
    async def create_function(self,*args,**kw): self._conn.create_function(*args,**kw)
    async def stop(self): await self.close()
    async def set_progress_handler(self,*args,**kw): self._conn.set_progress_handler(*args,**kw)

def connect(database,**kw): return Connection(database,**kw)
