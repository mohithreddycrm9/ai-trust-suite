import random

def test_blind_judge_mapping_round_trip():
    pairs=[("A","model-a"),("B","model-b")]
    random.Random(4).shuffle(pairs)
    hidden=dict(pairs)
    assert hidden["A"] in {"model-a","model-b"}
    # Unblinding is a server-side lookup, not exposed to the judge.
    scores={"A":9,"B":7}
    per_model={hidden[k]:v for k,v in scores.items()}
    assert per_model[hidden["A"]]==9 and per_model[hidden["B"]]==7

def test_shuffle_can_change_order():
    orders=[]
    for seed in range(20):
        x=["A","B"];random.Random(seed).shuffle(x);orders.append(tuple(x))
    assert ("A","B") in orders and ("B","A") in orders
