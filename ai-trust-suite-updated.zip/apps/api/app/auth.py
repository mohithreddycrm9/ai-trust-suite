import secrets
from datetime import datetime, timedelta, timezone
from uuid import UUID
import jwt
from fastapi import Depends, HTTPException, Request, Response
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from .config import settings
from .db import get_db
from .models import User, Organization, Membership
from .security import hash_password, verify_password

ALGORITHM = "HS256"
ROLES = {"Owner": 4, "Admin": 3, "Member": 2, "Viewer": 1}

def issue_token(user_id: UUID) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub": str(user_id), "iat": now, "exp": now + timedelta(minutes=settings.access_token_minutes)}, settings.jwt_secret, algorithm=ALGORITHM)

def decode_token(token: str) -> UUID:
    try:
        data = jwt.decode(token, settings.jwt_secret, algorithms=[ALGORITHM])
        return UUID(data["sub"])
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Invalid session") from exc

def set_auth_cookies(response: Response, token: str):
    csrf = secrets.token_urlsafe(32)
    response.set_cookie(settings.auth_cookie_name, token, httponly=True, secure=settings.cookie_secure, samesite="lax", domain=settings.cookie_domain, path="/")
    response.set_cookie(settings.csrf_cookie_name, csrf, httponly=False, secure=settings.cookie_secure, samesite="lax", domain=settings.cookie_domain, path="/")

def clear_auth_cookies(response: Response):
    response.delete_cookie(settings.auth_cookie_name, path="/", domain=settings.cookie_domain)
    response.delete_cookie(settings.csrf_cookie_name, path="/", domain=settings.cookie_domain)

async def current_user(request: Request, db: AsyncSession = Depends(get_db)) -> User:
    token = request.cookies.get(settings.auth_cookie_name)
    if not token:
        raise HTTPException(status_code=401, detail="Authentication required")
    user_id = decode_token(token)
    user = (await db.execute(select(User).where(User.id == user_id, User.is_active.is_(True)))).scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return user

async def current_membership(request: Request, db: AsyncSession = Depends(get_db), user: User = Depends(current_user)) -> Membership:
    org_header = request.headers.get("X-Organization-ID")
    stmt = select(Membership).where(Membership.user_id == user.id)
    if org_header:
        try: org_id = UUID(org_header)
        except ValueError: raise HTTPException(400, "Invalid organization")
        stmt = stmt.where(Membership.organization_id == org_id)
    membership = (await db.execute(stmt.order_by(Membership.created_at))).scalars().first()
    if not membership:
        raise HTTPException(403, "No organization membership")
    all_memberships=(await db.execute(select(Membership).where(Membership.user_id==user.id))).scalars().all()
    if not org_header and len(all_memberships)>1:
        raise HTTPException(400, "Organization selection required")
    return membership

def require_role(*allowed_roles: str):
    async def dependency(membership: Membership = Depends(current_membership)):
        if membership.role not in allowed_roles:
            raise HTTPException(403, "Insufficient role")
        return membership
    return dependency

def enforce_csrf(request: Request):
    if request.method in {"GET", "HEAD", "OPTIONS"}: return
    if request.url.path in {"/api/v1/auth/register", "/api/v1/auth/login"}: return
    cookie = request.cookies.get(settings.csrf_cookie_name)
    header = request.headers.get("X-CSRF-Token")
    if not cookie or not header or not secrets.compare_digest(cookie, header):
        raise HTTPException(403, "CSRF validation failed")

async def register_user(db: AsyncSession, email: str, password: str, organization_name: str):
    if (await db.execute(select(User).where(User.email == email.lower()))).scalar_one_or_none():
        raise HTTPException(409, "Email already registered")
    user = User(email=email.lower(), password_hash=hash_password(password))
    org = Organization(name=organization_name)
    db.add_all([user, org]); await db.flush()
    db.add(Membership(user_id=user.id, organization_id=org.id, role="Owner"))
    await db.commit(); await db.refresh(user); return user, org

async def authenticate(db: AsyncSession, email: str, password: str):
    user = (await db.execute(select(User).where(User.email == email.lower()))).scalar_one_or_none()
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return user
