import asyncio, ipaddress, socket
from urllib.parse import urlparse
from fastapi import HTTPException
from .config import settings

async def validate_base_url(url: str|None, provider: str):
    if not url: return
    p=urlparse(url)
    if p.scheme not in {"http","https"} or not p.hostname:
        raise HTTPException(400,"Invalid base_url")
    normalized=f"{p.scheme}://{p.hostname.lower()}:{p.port or (443 if p.scheme=='https' else 80)}"
    allow={x.strip().rstrip('/') for x in settings.ollama_allowed_base_urls.split(',') if x.strip()}
    if provider.lower()=="ollama" and normalized.rstrip('/') in allow:
        return
    try:
        infos=await asyncio.get_running_loop().run_in_executor(None, lambda: socket.getaddrinfo(p.hostname,p.port or 80,type=socket.SOCK_STREAM))
    except socket.gaierror as exc:
        raise HTTPException(400,"Unable to resolve base_url") from exc
    ips={ipaddress.ip_address(info[4][0]) for info in infos}
    for ip in ips:
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            raise HTTPException(400,"base_url resolves to a blocked network address")
