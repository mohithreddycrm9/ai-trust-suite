from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "sqlite+aiosqlite:///./test.db"
    encryption_key: str
    cors_origins: str = "http://localhost:3000"
    jwt_secret: str
    cookie_secure: bool = False
    cookie_domain: str | None = None
    csrf_cookie_name: str = "ai_trust_csrf"
    auth_cookie_name: str = "ai_trust_session"
    access_token_minutes: int = 60
    rate_limit_per_minute: int = 60
    ollama_allowed_base_urls: str = ""
    prompt_logging: bool = False
    model_timeout_seconds: float = 60

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
