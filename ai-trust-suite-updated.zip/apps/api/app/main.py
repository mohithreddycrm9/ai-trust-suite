import logging, time, uuid
from uuid import UUID
from fastapi import FastAPI, Depends, HTTPException, Request, Response, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, EmailStr
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession
from .config import settings
from .db import get_db
from .models import ModelConnection, ArenaRun, EvaluationScore, ModelExecution, User, KnowledgeDocument, KnowledgeChunk, VerifyRun, VerifyClaim, TestPack, TestCase, TestRun, TestResult, SecurityRun, SecurityFinding
from .auth import register_user, authenticate, issue_token, set_auth_cookies, clear_auth_cookies, current_user, current_membership, require_role, enforce_csrf
from .rate_limit import rate_limit
from .ssrf import validate_base_url
from .services import create_model, test_model_connection, get_scoped_model
from .evaluation.engine import EvaluationEngine
from .audit import audit
from .errors import ProviderError, JudgeOutputError, error_response
from .evaluation.text import chunk_text, embed_text
from .evaluation.verify import run_verify
from .evaluation.testlab import ensure_defaults, run_test_pack
from .evaluation.secure import run_security
import hashlib, json

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger=logging.getLogger("ai_trust_suite")
app=FastAPI(title="AI Trust Suite API",version="0.2.0")
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_origins.split(","),allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

from fastapi.exceptions import RequestValidationError
from fastapi.exception_handlers import http_exception_handler
from starlette.exceptions import HTTPException as StarletteHTTPException

@app.exception_handler(StarletteHTTPException)
async def http_errors(request, exc):
    return error_response(request, exc.status_code, "HTTP_ERROR", str(exc.detail))

@app.exception_handler(RequestValidationError)
async def validation_errors(request, exc):
    return error_response(request, 422, "VALIDATION_ERROR", "Request validation failed")

@app.exception_handler(ProviderError)
async def provider_errors(request, exc):
    return error_response(request, 502, exc.code, exc.message)

@app.exception_handler(JudgeOutputError)
async def judge_errors(request, exc):
    return error_response(request, 422, "INVALID_JUDGE_OUTPUT", str(exc))

@app.middleware("http")
async def request_context(request:Request,call_next):
    request.state.request_id=request.headers.get("X-Request-ID",str(uuid.uuid4()))
    start=time.perf_counter()
    try:
        enforce_csrf(request); rate_limit(request)
        response=await call_next(request)
    except HTTPException as e:
        return error_response(request,e.status_code,"HTTP_ERROR",str(e.detail))
    except ProviderError as e:
        return error_response(request,502,e.code,e.message)
    except JudgeOutputError as e:
        return error_response(request,422,"INVALID_JUDGE_OUTPUT",str(e))
    except Exception:
        logger.exception("request_failed request_id=%s method=%s path=%s",request.state.request_id,request.method,request.url.path)
        return error_response(request,500,"INTERNAL_ERROR","An unexpected error occurred")
    response.headers["X-Request-ID"]=request.state.request_id
    logger.info("request_complete request_id=%s method=%s path=%s status=%s latency_ms=%.1f",request.state.request_id,request.method,request.url.path,response.status_code,(time.perf_counter()-start)*1000)
    return response

class RegisterIn(BaseModel): email:EmailStr; password:str=Field(min_length=12); organization_name:str=Field(min_length=2,max_length=160)
class LoginIn(BaseModel): email:EmailStr; password:str
class ModelIn(BaseModel): name:str; provider:str; model:str; api_key:str|None=None; base_url:str|None=None
class RunIn(BaseModel): model_id:UUID; prompt:str=Field(min_length=1); system_prompt:str|None=None
class ArenaIn(BaseModel): model_a_id:UUID; model_b_id:UUID; judge_model_id:UUID; prompt:str=Field(min_length=1)

@app.get("/health")
async def health(): return {"status":"ok"}

@app.post("/api/v1/auth/register")
async def register(body:RegisterIn,response:Response,db:AsyncSession=Depends(get_db)):
    user,org=await register_user(db,body.email,body.password,body.organization_name); set_auth_cookies(response,issue_token(user.id)); return {"user":{"id":str(user.id),"email":user.email},"organization":{"id":str(org.id),"name":org.name}}

@app.post("/api/v1/auth/login")
async def login(body:LoginIn,response:Response,db:AsyncSession=Depends(get_db)):
    user=await authenticate(db,body.email,body.password);set_auth_cookies(response,issue_token(user.id));return {"user":{"id":str(user.id),"email":user.email}}

@app.post("/api/v1/auth/logout")
async def logout(response:Response,user=Depends(current_user)): clear_auth_cookies(response);return {"ok":True}

@app.get("/api/v1/auth/me")
async def me(user=Depends(current_user),membership=Depends(current_membership)):return {"id":str(user.id),"email":user.email,"organization_id":str(membership.organization_id),"role":membership.role}

@app.get("/api/v1/models")
async def models(db=Depends(get_db),membership=Depends(current_membership)):
    xs=(await db.execute(select(ModelConnection).where(ModelConnection.organization_id==membership.organization_id))).scalars().all()
    return [{"id":str(x.id),"name":x.name,"provider":x.provider,"model":x.model,"health_status":x.health_status,"last_success_at":x.last_success_at,"last_error":x.last_error} for x in xs]

@app.post("/api/v1/models")
async def add_model(body:ModelIn,db=Depends(get_db),membership=Depends(require_role("Owner","Admin")),user=Depends(current_user)):
    await validate_base_url(body.base_url,body.provider)
    x=await create_model(db,membership.organization_id,body);await audit(db,membership.organization_id,user.id,"MODEL_CONNECTED","model",str(x.id));await db.commit()
    return {"id":str(x.id),"name":x.name,"provider":x.provider,"model":x.model,"health_status":x.health_status}

@app.post("/api/v1/models/{model_id}/test")
async def test_model(model_id:UUID,db=Depends(get_db),membership=Depends(current_membership),user=Depends(current_user)):
    x=await get_scoped_model(db,membership.organization_id,model_id)
    if not x: raise HTTPException(404,"Model not found")
    try:
        await test_model_connection(x); await audit(db,membership.organization_id,user.id,"MODEL_CONNECTION_TESTED","model",str(x.id),{"status":"success"});await db.commit()
        return {"ok":True,"health_status":x.health_status,"last_success_at":x.last_success_at}
    except ProviderError:
        await db.commit();raise

class ModelUpdate(BaseModel):
    name:str|None=None
    api_key:str|None=None
    base_url:str|None=None

@app.patch("/api/v1/models/{model_id}")
async def update_model(model_id:UUID,body:ModelUpdate,db=Depends(get_db),membership=Depends(require_role("Owner","Admin")),user=Depends(current_user)):
    x=await get_scoped_model(db,membership.organization_id,model_id)
    if not x: raise HTTPException(404,"Model not found")
    if body.base_url is not None:
        await validate_base_url(body.base_url,x.provider);x.base_url=body.base_url
    if body.name is not None:x.name=body.name
    if body.api_key is not None:
        from .security import encrypt_secret
        x.encrypted_api_key=encrypt_secret(body.api_key);x.last_error=None;x.health_status="unknown"
        await audit(db,membership.organization_id,user.id,"API_KEY_UPDATED","model",str(x.id))
    await db.commit()
    return {"id":str(x.id),"name":x.name,"provider":x.provider,"model":x.model,"health_status":x.health_status}

@app.delete("/api/v1/models/{model_id}")
async def remove_model(model_id:UUID,db=Depends(get_db),membership=Depends(require_role("Owner","Admin"))):
    x=await get_scoped_model(db,membership.organization_id,model_id)
    if not x: raise HTTPException(404,"Model not found")
    await db.delete(x);await db.commit();return {"ok":True}

@app.post("/api/v1/runs")
async def run(body:RunIn,db=Depends(get_db),membership=Depends(current_membership)):
    x=await get_scoped_model(db,membership.organization_id,body.model_id)
    if not x:raise HTTPException(404,"Model not found")
    from .models import EvaluationRun
    ev=EvaluationRun(organization_id=membership.organization_id,kind="run",status="running",prompt=body.prompt);db.add(ev);await db.flush()
    r=await EvaluationEngine(db).execute(org_id=membership.organization_id,evaluation_id=ev.id,connection=x,prompt=body.prompt,system_prompt=body.system_prompt);ev.status="completed";await db.commit()
    return {"id":str(r.id),"response":r.response,"provider":r.provider,"model":r.model,"latency_ms":r.latency_ms,"input_tokens":r.input_tokens,"output_tokens":r.output_tokens,"estimated_cost":r.estimated_cost,"cost_status":r.cost_status}

@app.post("/api/v1/arena/run")
async def run_arena(body:ArenaIn,db=Depends(get_db),membership=Depends(current_membership),user=Depends(current_user)):
    ids=[body.model_a_id,body.model_b_id,body.judge_model_id]
    xs=(await db.execute(select(ModelConnection).where(ModelConnection.organization_id==membership.organization_id,ModelConnection.id.in_(ids)))).scalars().all();m={x.id:x for x in xs}
    if len(m)!=3:raise HTTPException(404,"One or more models not found")
    ev_preview=None
    await audit(db,membership.organization_id,user.id,"EVALUATION_STARTED","arena","pending");await db.flush()
    result=await EvaluationEngine(db).arena(org_id=membership.organization_id,prompt=body.prompt,model_a=m[body.model_a_id],model_b=m[body.model_b_id],judge=m[body.judge_model_id])
    arena,sa,sb,a,b,j=result
    await audit(db,membership.organization_id,user.id,"EVALUATION_COMPLETED","arena",str(arena.id));await db.commit()
    return {"id":str(arena.id),"evaluation_run_id":str(arena.evaluation_run_id),"model_a":{"id":str(m[body.model_a_id].id),"response":a.response,"latency_ms":a.latency_ms,"input_tokens":a.input_tokens,"output_tokens":a.output_tokens,"estimated_cost":a.estimated_cost,"cost_status":a.cost_status,"scores":sa.model_dump()},"model_b":{"id":str(m[body.model_b_id].id),"response":b.response,"latency_ms":b.latency_ms,"input_tokens":b.input_tokens,"output_tokens":b.output_tokens,"estimated_cost":b.estimated_cost,"cost_status":b.cost_status,"scores":sb.model_dump()}}

@app.get("/api/v1/reports/{run_id}")
async def report(run_id:UUID,db=Depends(get_db),membership=Depends(current_membership)):
    r=(await db.execute(select(ArenaRun).where(ArenaRun.id==run_id,ArenaRun.organization_id==membership.organization_id))).scalar_one_or_none()
    if not r:raise HTTPException(404,"Report not found")
    a=(await db.execute(select(ModelExecution).where(ModelExecution.id==r.model_a_execution_id))).scalar_one();b=(await db.execute(select(ModelExecution).where(ModelExecution.id==r.model_b_execution_id))).scalar_one()
    scores=(await db.execute(select(EvaluationScore).where(EvaluationScore.evaluation_run_id==r.evaluation_run_id))).scalars().all()
    def clean_score(s):
        return {"accuracy":s.accuracy,"honesty":s.honesty,"safety":s.safety,"relevance":s.relevance,"clarity":s.clarity,"instruction_following":s.instruction_following,"rationale":s.rationale}
    return {"id":str(r.id),"model_a_response":a.response,"model_b_response":b.response,"model_a":{"id":str(r.response_a_model_id),"scores":clean_score(next(x for x in scores if x.model_connection_id==r.response_a_model_id))},"model_b":{"id":str(r.response_b_model_id),"scores":clean_score(next(x for x in scores if x.model_connection_id==r.response_b_model_id))}}


class VerifyIn(BaseModel):
    model_id: UUID
    answer: str = Field(min_length=1, max_length=100000)

class TestRunIn(BaseModel):
    model_id: UUID
    pack_id: UUID

class SecureIn(BaseModel):
    model_id: UUID

@app.post("/api/v1/knowledge/documents")
async def upload_knowledge(file: UploadFile = File(...), db: AsyncSession = Depends(get_db), membership=Depends(require_role("Owner","Admin","Member")), user=Depends(current_user)):
    raw=await file.read()
    if len(raw)>10*1024*1024: raise HTTPException(413,"Document exceeds the 10 MB limit")
    content_type=file.content_type or "text/plain"
    allowed={"text/plain","text/markdown","text/csv","application/json","application/octet-stream"}
    if content_type not in allowed and not (file.filename or "").lower().endswith((".txt",".md",".csv",".json")):
        raise HTTPException(415,"Only text, markdown, CSV and JSON documents are supported in this release")
    try: text_content=raw.decode("utf-8")
    except UnicodeDecodeError: raise HTTPException(415,"Document must be UTF-8 text")
    doc=KnowledgeDocument(organization_id=membership.organization_id,name=file.filename or "document",content_type=content_type,source_hash=hashlib.sha256(raw).hexdigest())
    db.add(doc);await db.flush()
    chunks=chunk_text(text_content)
    for idx,content in enumerate(chunks):
        emb=embed_text(content)
        ch=KnowledgeChunk(organization_id=membership.organization_id,document_id=doc.id,chunk_index=idx,content=content,embedding_json=json.dumps(emb,separators=(",",":")))
        db.add(ch);await db.flush()
        if db.bind and db.bind.dialect.name=="postgresql":
            from sqlalchemy import text as sql_text
            await db.execute(sql_text("UPDATE knowledge_chunks SET embedding = CAST(:embedding AS vector) WHERE id = :id"),{"embedding":str(emb),"id":ch.id})
    await audit(db,membership.organization_id,user.id,"KNOWLEDGE_DOCUMENT_UPLOADED","knowledge_document",str(doc.id),{"chunks":len(chunks)})
    await db.commit()
    return {"id":str(doc.id),"name":doc.name,"chunks":len(chunks),"source_hash":doc.source_hash}

@app.get("/api/v1/knowledge/documents")
async def list_knowledge(db=Depends(get_db),membership=Depends(current_membership)):
    docs=(await db.execute(select(KnowledgeDocument).where(KnowledgeDocument.organization_id==membership.organization_id).order_by(KnowledgeDocument.created_at.desc()))).scalars().all()
    out=[]
    for d in docs:
        count=(await db.execute(select(KnowledgeChunk).where(KnowledgeChunk.document_id==d.id))).scalars().all()
        out.append({"id":str(d.id),"name":d.name,"content_type":d.content_type,"chunks":len(count),"created_at":d.created_at})
    return out

@app.post("/api/v1/verify/run")
async def verify(body:VerifyIn,db=Depends(get_db),membership=Depends(current_membership),user=Depends(current_user)):
    model=await get_scoped_model(db,membership.organization_id,body.model_id)
    if not model: raise HTTPException(404,"Model not found")
    # The answer is supplied by the caller; the shared engine remains the execution boundary for generated answers elsewhere.
    fake_execution=None
    run,claims=await run_verify(db,membership.organization_id,model.id,fake_execution,body.answer)
    await audit(db,membership.organization_id,user.id,"EVALUATION_COMPLETED","verify",str(run.id),{"claims":len(claims)})
    await db.commit()
    return {"id":str(run.id),"claim_count":run.claim_count,"supported_count":run.supported_count,"unsupported_count":run.unsupported_count,"contradiction_count":run.contradiction_count,"claims":claims}

@app.get("/api/v1/verify/runs/{run_id}")
async def verify_report(run_id:UUID,db=Depends(get_db),membership=Depends(current_membership)):
    run=(await db.execute(select(VerifyRun).where(VerifyRun.id==run_id,VerifyRun.organization_id==membership.organization_id))).scalar_one_or_none()
    if not run: raise HTTPException(404,"Verify run not found")
    claims=(await db.execute(select(VerifyClaim).where(VerifyClaim.verify_run_id==run.id).order_by(VerifyClaim.created_at))).scalars().all()
    return {"id":str(run.id),"claim_count":run.claim_count,"supported_count":run.supported_count,"unsupported_count":run.unsupported_count,"contradiction_count":run.contradiction_count,"claims":[{"id":str(c.id),"claim":c.claim,"verdict":c.verdict,"confidence":c.confidence,"evidence":c.evidence,"rationale":c.rationale} for c in claims]}

@app.get("/api/v1/test-lab/packs")
async def test_packs(db=Depends(get_db),membership=Depends(current_membership)):
    await ensure_defaults(db,membership.organization_id)
    packs=(await db.execute(select(TestPack).where(TestPack.organization_id==membership.organization_id).order_by(TestPack.category,TestPack.name))).scalars().all()
    out=[]
    for p in packs:
        cases=(await db.execute(select(TestCase).where(TestCase.test_pack_id==p.id))).scalars().all()
        out.append({"id":str(p.id),"slug":p.slug,"name":p.name,"category":p.category,"description":p.description,"case_count":len(cases)})
    return out

@app.post("/api/v1/test-lab/run")
async def test_lab(body:TestRunIn,db=Depends(get_db),membership=Depends(current_membership),user=Depends(current_user)):
    pack=(await db.execute(select(TestPack).where(TestPack.id==body.pack_id,TestPack.organization_id==membership.organization_id))).scalar_one_or_none()
    model=await get_scoped_model(db,membership.organization_id,body.model_id)
    if not pack or not model: raise HTTPException(404,"Test pack or model not found")
    await audit(db,membership.organization_id,user.id,"EVALUATION_STARTED","test_lab",str(pack.id),{"model_id":str(model.id)})
    tr,results=await run_test_pack(db,membership.organization_id,pack,model)
    await audit(db,membership.organization_id,user.id,"EVALUATION_COMPLETED","test_lab",str(tr.id),{"pass_rate":tr.pass_rate})
    await db.commit()
    return {"id":str(tr.id),"pack":{"id":str(pack.id),"name":pack.name},"model":{"id":str(model.id),"name":model.name,"provider":model.provider,"model":model.model},"status":tr.status,"pass_rate":tr.pass_rate,"results":results}

@app.get("/api/v1/test-lab/runs/{run_id}")
async def test_lab_report(run_id:UUID,db=Depends(get_db),membership=Depends(current_membership)):
    run=(await db.execute(select(TestRun).where(TestRun.id==run_id,TestRun.organization_id==membership.organization_id))).scalar_one_or_none()
    if not run: raise HTTPException(404,"Test run not found")
    rows=(await db.execute(select(TestResult,TestCase).join(TestCase,TestCase.id==TestResult.test_case_id).where(TestResult.test_run_id==run.id))).all()
    return {"id":str(run.id),"status":run.status,"pass_rate":run.pass_rate,"results":[{"id":str(r.id),"name":c.name,"passed":r.passed,"score":r.score,"finding":r.finding} for r,c in rows]}

@app.post("/api/v1/secure/run")
async def secure(body:SecureIn,db=Depends(get_db),membership=Depends(current_membership),user=Depends(current_user)):
    model=await get_scoped_model(db,membership.organization_id,body.model_id)
    if not model: raise HTTPException(404,"Model not found")
    await audit(db,membership.organization_id,user.id,"EVALUATION_STARTED","secure",str(model.id))
    run,findings=await run_security(db,membership.organization_id,model)
    await audit(db,membership.organization_id,user.id,"EVALUATION_COMPLETED","secure",str(run.id),{"blocked":run.blocked_count,"attacks":run.attack_count})
    await db.commit()
    return {"id":str(run.id),"attack_count":run.attack_count,"blocked_count":run.blocked_count,"risk_score":run.risk_score,"findings":findings}

@app.get("/api/v1/secure/runs/{run_id}")
async def secure_report(run_id:UUID,db=Depends(get_db),membership=Depends(current_membership)):
    run=(await db.execute(select(SecurityRun).where(SecurityRun.id==run_id,SecurityRun.organization_id==membership.organization_id))).scalar_one_or_none()
    if not run: raise HTTPException(404,"Security run not found")
    rows=(await db.execute(select(SecurityFinding).where(SecurityFinding.security_run_id==run.id).order_by(SecurityFinding.created_at))).scalars().all()
    return {"id":str(run.id),"attack_count":run.attack_count,"blocked_count":run.blocked_count,"risk_score":run.risk_score,"findings":[{"id":str(x.id),"attack_type":x.attack_type,"passed":x.passed,"score":x.score,"finding":x.finding,"payload":x.payload} for x in rows]}
