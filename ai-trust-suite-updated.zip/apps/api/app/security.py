import base64, hashlib, hmac, os
from cryptography.fernet import Fernet
from .config import settings
try:
    from pwdlib import PasswordHash
    _password_hash = PasswordHash.recommended()
except ImportError:
    _password_hash = None

def encrypt_secret(value: str) -> str:
    return Fernet(settings.encryption_key.encode()).encrypt(value.encode()).decode()

def decrypt_secret(value: str) -> str:
    return Fernet(settings.encryption_key.encode()).decrypt(value.encode()).decode()

def hash_password(password: str) -> str:
    if _password_hash:return _password_hash.hash(password)
    salt=os.urandom(16);dk=hashlib.pbkdf2_hmac("sha256",password.encode(),salt,310000)
    return "pbkdf2$310000$"+base64.urlsafe_b64encode(salt).decode()+"$"+base64.urlsafe_b64encode(dk).decode()

def verify_password(password: str, hashed: str) -> bool:
    if hashed.startswith("pbkdf2$"):
        _,iters,salt,expected=hashed.split("$",3);actual=hashlib.pbkdf2_hmac("sha256",password.encode(),base64.urlsafe_b64decode(salt),int(iters))
        return hmac.compare_digest(base64.urlsafe_b64decode(expected),actual)
    if _password_hash:return _password_hash.verify(password,hashed)
    return False
