import time
from collections import defaultdict, deque
from fastapi import Request
from .config import settings

_buckets = defaultdict(deque)

def rate_limit(request: Request):
    now=time.monotonic(); key=f"{request.client.host if request.client else 'unknown'}:{request.url.path}"
    q=_buckets[key]
    while q and now-q[0]>60:q.popleft()
    if len(q)>=settings.rate_limit_per_minute:
        from fastapi import HTTPException
        raise HTTPException(429,"Rate limit exceeded")
    q.append(now)
