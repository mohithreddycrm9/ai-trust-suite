import httpx
from .base import ModelProvider,GenerationRequest,GenerationResponse,Usage
from ..errors import ProviderError
class OllamaProvider(ModelProvider):
    def __init__(self,model,base_url):self.model,self.base_url=model,base_url.rstrip("/")
    async def generate(self,request):
        messages=([{"role":"system","content":request.system_prompt}] if request.system_prompt else [])+[{"role":"user","content":request.prompt}]
        p={"model":self.model,"messages":messages,"stream":False,"options":{"temperature":request.temperature}}
        try:
            async with httpx.AsyncClient(timeout=request.timeout) as c:r=await c.post(self.base_url+"/api/chat",json=p)
        except httpx.TimeoutException as e:raise ProviderError("PROVIDER_TIMEOUT","Provider request timed out",True) from e
        except httpx.HTTPError as e:raise ProviderError("PROVIDER_NETWORK_ERROR","Provider network request failed",True) from e
        if r.status_code==429:raise ProviderError("PROVIDER_RATE_LIMIT","Provider rate limit reached",True)
        if r.status_code in (401,403):raise ProviderError("PROVIDER_AUTH_ERROR","Provider authentication failed")
        if r.status_code>=500:raise ProviderError("PROVIDER_SERVER_ERROR","Provider server error",True)
        if r.status_code>=400:raise ProviderError("PROVIDER_BAD_REQUEST","Provider rejected the request")
        d=r.json();u=d.get("prompt_eval_count") or d.get("prompt_eval_count",0);v=d.get("eval_count") or d.get("eval_count",0)
        return GenerationResponse(d["message"]["content"],Usage(u or None,v or None))
