import httpx
from .base import ModelProvider,GenerationRequest,GenerationResponse,Usage
from ..errors import ProviderError

class OpenAIProvider(ModelProvider):
    def __init__(self,key,model,base_url="https://api.openai.com/v1"):
        self.key,self.model,self.base_url=key,model,base_url.rstrip("/")
    async def generate(self,request):
        messages=([{"role":"system","content":request.system_prompt}] if request.system_prompt else [])+[{"role":"user","content":request.prompt}]
        p={"model":self.model,"messages":messages,"temperature":request.temperature,"max_tokens":request.max_tokens}
        if request.structured_output:p["response_format"]={"type":"json_schema","json_schema":request.structured_output}
        try:
            async with httpx.AsyncClient(timeout=request.timeout) as c:r=await c.post(self.base_url+"/chat/completions",headers={"Authorization":"Bearer "+self.key},json=p)
        except httpx.TimeoutException as e:raise ProviderError("PROVIDER_TIMEOUT","Provider request timed out",True) from e
        except httpx.HTTPError as e:raise ProviderError("PROVIDER_NETWORK_ERROR","Provider network request failed",True) from e
        if r.status_code==429:raise ProviderError("PROVIDER_RATE_LIMIT","Provider rate limit reached",True)
        if r.status_code in (401,403):raise ProviderError("PROVIDER_AUTH_ERROR","Provider authentication failed")
        if r.status_code>=500:raise ProviderError("PROVIDER_SERVER_ERROR","Provider server error",True)
        if r.status_code>=400:raise ProviderError("PROVIDER_BAD_REQUEST","Provider rejected the request")
        d=r.json();u=d.get("usage",{})
        return GenerationResponse(d["choices"][0]["message"]["content"],Usage(u.get("prompt_tokens"),u.get("completion_tokens")),d["choices"][0].get("finish_reason"))
