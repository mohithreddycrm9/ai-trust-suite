import httpx
from .base import ModelProvider,GenerationRequest,GenerationResponse,Usage
from ..errors import ProviderError
class AnthropicProvider(ModelProvider):
    def __init__(self,key,model,base_url="https://api.anthropic.com"):self.key,self.model,self.base_url=key,model,base_url.rstrip("/")
    async def generate(self,request):
        p={"model":self.model,"max_tokens":request.max_tokens,"temperature":request.temperature,"messages":[{"role":"user","content":request.prompt}]}
        if request.system_prompt:p["system"]=request.system_prompt
        try:
            async with httpx.AsyncClient(timeout=request.timeout) as c:r=await c.post(self.base_url+"/v1/messages",headers={"x-api-key":self.key,"anthropic-version":"2023-06-01","content-type":"application/json"},json=p)
        except httpx.TimeoutException as e:raise ProviderError("PROVIDER_TIMEOUT","Provider request timed out",True) from e
        except httpx.HTTPError as e:raise ProviderError("PROVIDER_NETWORK_ERROR","Provider network request failed",True) from e
        if r.status_code==429:raise ProviderError("PROVIDER_RATE_LIMIT","Provider rate limit reached",True)
        if r.status_code in (401,403):raise ProviderError("PROVIDER_AUTH_ERROR","Provider authentication failed")
        if r.status_code>=500:raise ProviderError("PROVIDER_SERVER_ERROR","Provider server error",True)
        if r.status_code>=400:raise ProviderError("PROVIDER_BAD_REQUEST","Provider rejected the request")
        d=r.json();u=d.get("usage",{})
        return GenerationResponse("".join(x.get("text","") for x in d.get("content",[])),Usage(u.get("input_tokens"),u.get("output_tokens")),d.get("stop_reason"))
