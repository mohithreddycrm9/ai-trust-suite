from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

@dataclass
class GenerationRequest:
    prompt: str
    system_prompt: str | None = None
    temperature: float = 0.2
    max_tokens: int = 1024
    timeout: float = 60
    structured_output: dict[str, Any] | None = None

@dataclass
class Usage:
    input_tokens: int | None = None
    output_tokens: int | None = None

@dataclass
class GenerationResponse:
    text: str
    usage: Usage = field(default_factory=Usage)
    finish_reason: str | None = None

class ModelProvider(ABC):
    @abstractmethod
    async def generate(self, request: GenerationRequest) -> GenerationResponse: ...
