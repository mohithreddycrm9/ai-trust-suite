import httpx
from .base import ModelProvider,GenerationRequest,GenerationResponse,Usage
from ..errors import ProviderError
class GeminiProvider(ModelProvider):
    def __init__(self,key,model):self.key,self.model=key,model
    async def generate(self,request):
        url=f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        p={"contents":[{"parts":[{"text":request.prompt}]}],"generationConfig":{"temperature":request.temperature,"maxOutputTokens":request.max_tokens}}
        if request.system_prompt:p["systemInstruction"]={"parts":[{"text":request.system_prompt}]}
        try:
            async with httpx.AsyncClient(timeout=request.timeout) as c:r=await c.post(url,params={"key":self.key},json=p)
        except httpx.TimeoutException as e:raise ProviderError("PROVIDER_TIMEOUT","Provider request timed out",True) from e
        except httpx.HTTPError as e:raise ProviderError("PROVIDER_NETWORK_ERROR","Provider network request failed",True) from e
        if r.status_code==429:raise ProviderError("PROVIDER_RATE_LIMIT","Provider rate limit reached",True)
        if r.status_code in (401,403):raise ProviderError("PROVIDER_AUTH_ERROR","Provider authentication failed")
        if r.status_code>=500:raise ProviderError("PROVIDER_SERVER_ERROR","Provider server error",True)
        if r.status_code>=400:raise ProviderError("PROVIDER_BAD_REQUEST","Provider rejected the request")
        d=r.json();u=d.get("usageMetadata",{})
        return GenerationResponse(d["candidates"][0]["content"]["parts"][0]["text"],Usage(u.get("promptTokenCount"),u.get("candidatesTokenCount") or u.get("outputTokenCount")),d.get("candidates",[{}])[0].get("finishReason"))
