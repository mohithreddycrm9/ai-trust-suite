from .openai import OpenAIProvider
from .anthropic import AnthropicProvider
from .gemini import GeminiProvider
from .ollama import OllamaProvider

def provider_for(kind,model,secret,base_url=None):
    if kind=="openai":return OpenAIProvider(secret,model,base_url or "https://api.openai.com/v1")
    if kind=="anthropic":return AnthropicProvider(secret,model,base_url or "https://api.anthropic.com")
    if kind=="gemini":return GeminiProvider(secret,model)
    if kind=="ollama":return OllamaProvider(model,base_url or "http://localhost:11434")
    raise ValueError("Unsupported provider")
