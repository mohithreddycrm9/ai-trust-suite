import uuid
from datetime import datetime
from sqlalchemy import String, Text, Float, Integer, DateTime, Boolean, ForeignKey, Index, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

def uid(): return uuid.uuid4()

class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class User(TimestampMixin, Base):
    __tablename__ = "users"
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

class Organization(TimestampMixin, Base):
    __tablename__ = "organizations"
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    name: Mapped[str] = mapped_column(String(160))

class Membership(TimestampMixin, Base):
    __tablename__ = "memberships"
    __table_args__ = (UniqueConstraint("user_id", "organization_id", name="uq_membership_user_org"), Index("ix_membership_org", "organization_id"))
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(20), default="Member")

class ModelConnection(TimestampMixin, Base):
    __tablename__ = "model_connections"
    __table_args__ = (Index("ix_model_connections_org", "organization_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(120))
    provider: Mapped[str] = mapped_column(String(40))
    model: Mapped[str] = mapped_column(String(120))
    encrypted_api_key: Mapped[str | None] = mapped_column(Text, nullable=True)
    base_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    health_status: Mapped[str] = mapped_column(String(30), default="unknown")
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)

class EvaluationRun(TimestampMixin, Base):
    __tablename__ = "evaluation_runs"
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(30), default="running")
    prompt: Mapped[str] = mapped_column(Text)

class ModelExecution(TimestampMixin, Base):
    __tablename__ = "model_executions"
    __table_args__ = (Index("ix_model_exec_eval", "evaluation_run_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    evaluation_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("evaluation_runs.id", ondelete="CASCADE"))
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    model_connection_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_connections.id", ondelete="CASCADE"))
    provider: Mapped[str] = mapped_column(String(40))
    model: Mapped[str] = mapped_column(String(120))
    prompt: Mapped[str] = mapped_column(Text)
    response: Mapped[str] = mapped_column(Text)
    latency_ms: Mapped[float] = mapped_column(Float)
    input_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    output_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    estimated_cost: Mapped[float | None] = mapped_column(Float, nullable=True)
    cost_status: Mapped[str] = mapped_column(String(20), default="unknown")
    is_judge: Mapped[bool] = mapped_column(Boolean, default=False)

class EvaluationScore(TimestampMixin, Base):
    __tablename__ = "evaluation_scores"
    __table_args__ = (Index("ix_scores_eval", "evaluation_run_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    evaluation_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("evaluation_runs.id", ondelete="CASCADE"))
    model_connection_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_connections.id", ondelete="CASCADE"))
    accuracy: Mapped[float] = mapped_column(Float)
    honesty: Mapped[float] = mapped_column(Float)
    safety: Mapped[float] = mapped_column(Float)
    relevance: Mapped[float] = mapped_column(Float)
    clarity: Mapped[float] = mapped_column(Float)
    instruction_following: Mapped[float] = mapped_column(Float)
    rationale: Mapped[str] = mapped_column(Text)

class ArenaRun(TimestampMixin, Base):
    __tablename__ = "arena_runs"
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    evaluation_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("evaluation_runs.id", ondelete="CASCADE"), unique=True)
    model_a_execution_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_executions.id"))
    model_b_execution_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_executions.id"))
    judge_execution_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_executions.id"))
    response_a_model_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_connections.id"))
    response_b_model_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_connections.id"))
    blind_order: Mapped[str] = mapped_column(String(1))


class KnowledgeDocument(TimestampMixin, Base):
    __tablename__ = "knowledge_documents"
    __table_args__ = (Index("ix_knowledge_documents_org", "organization_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    content_type: Mapped[str] = mapped_column(String(100), default="text/plain")
    source_hash: Mapped[str] = mapped_column(String(64))

class KnowledgeChunk(TimestampMixin, Base):
    __tablename__ = "knowledge_chunks"
    __table_args__ = (Index("ix_knowledge_chunks_document", "document_id"), Index("ix_knowledge_chunks_org", "organization_id"))
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    document_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("knowledge_documents.id", ondelete="CASCADE"), index=True)
    chunk_index: Mapped[int] = mapped_column(Integer)
    content: Mapped[str] = mapped_column(Text)
    embedding_json: Mapped[str] = mapped_column(Text)

class TestPack(TimestampMixin, Base):
    __tablename__ = "test_packs"
    __table_args__ = (Index("ix_test_packs_org", "organization_id"), UniqueConstraint("organization_id", "slug", name="uq_test_pack_org_slug"))
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    slug: Mapped[str] = mapped_column(String(120))
    name: Mapped[str] = mapped_column(String(180))
    category: Mapped[str] = mapped_column(String(60))
    description: Mapped[str] = mapped_column(Text, default="")

class TestCase(TimestampMixin, Base):
    __tablename__ = "test_cases"
    __table_args__ = (Index("ix_test_cases_pack", "test_pack_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    test_pack_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("test_packs.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(180))
    prompt: Mapped[str] = mapped_column(Text)
    expected_behavior: Mapped[str] = mapped_column(Text, default="")
    attack_type: Mapped[str | None] = mapped_column(String(80), nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)

class TestRun(TimestampMixin, Base):
    __tablename__ = "test_runs"
    __table_args__ = (Index("ix_test_runs_org", "organization_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    evaluation_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("evaluation_runs.id", ondelete="CASCADE"), index=True)
    test_pack_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("test_packs.id", ondelete="CASCADE"), index=True)
    model_connection_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_connections.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String(30), default="running")
    pass_rate: Mapped[float | None] = mapped_column(Float, nullable=True)

class TestResult(TimestampMixin, Base):
    __tablename__ = "test_results"
    __table_args__ = (Index("ix_test_results_run", "test_run_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    test_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("test_runs.id", ondelete="CASCADE"), index=True)
    test_case_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("test_cases.id", ondelete="CASCADE"), index=True)
    model_execution_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_executions.id", ondelete="CASCADE"), index=True)
    passed: Mapped[bool] = mapped_column(Boolean)
    score: Mapped[float] = mapped_column(Float)
    finding: Mapped[str] = mapped_column(Text)

class VerifyRun(TimestampMixin, Base):
    __tablename__ = "verify_runs"
    __table_args__ = (Index("ix_verify_runs_org", "organization_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    evaluation_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("evaluation_runs.id", ondelete="CASCADE"), index=True)
    model_connection_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_connections.id", ondelete="CASCADE"), index=True)
    claim_count: Mapped[int] = mapped_column(Integer, default=0)
    supported_count: Mapped[int] = mapped_column(Integer, default=0)
    unsupported_count: Mapped[int] = mapped_column(Integer, default=0)
    contradiction_count: Mapped[int] = mapped_column(Integer, default=0)

class VerifyClaim(TimestampMixin, Base):
    __tablename__ = "verify_claims"
    __table_args__ = (Index("ix_verify_claims_run", "verify_run_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    verify_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("verify_runs.id", ondelete="CASCADE"), index=True)
    claim: Mapped[str] = mapped_column(Text)
    verdict: Mapped[str] = mapped_column(String(30))
    confidence: Mapped[float] = mapped_column(Float)
    evidence: Mapped[str] = mapped_column(Text, default="")
    rationale: Mapped[str] = mapped_column(Text, default="")

class SecurityRun(TimestampMixin, Base):
    __tablename__ = "security_runs"
    __table_args__ = (Index("ix_security_runs_org", "organization_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    evaluation_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("evaluation_runs.id", ondelete="CASCADE"), index=True)
    model_connection_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("model_connections.id", ondelete="CASCADE"), index=True)
    attack_count: Mapped[int] = mapped_column(Integer, default=0)
    blocked_count: Mapped[int] = mapped_column(Integer, default=0)
    risk_score: Mapped[float] = mapped_column(Float, default=0)

class SecurityFinding(TimestampMixin, Base):
    __tablename__ = "security_findings"
    __table_args__ = (Index("ix_security_findings_run", "security_run_id"),)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    security_run_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("security_runs.id", ondelete="CASCADE"), index=True)
    attack_type: Mapped[str] = mapped_column(String(80))
    payload: Mapped[str] = mapped_column(Text)
    passed: Mapped[bool] = mapped_column(Boolean)
    score: Mapped[float] = mapped_column(Float)
    finding: Mapped[str] = mapped_column(Text)

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uid)
    organization_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    actor_user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"))
    event_type: Mapped[str] = mapped_column(String(80), index=True)
    entity_type: Mapped[str] = mapped_column(String(80))
    entity_id: Mapped[str] = mapped_column(String(80))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")
