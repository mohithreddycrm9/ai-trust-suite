import uuid, logging
from fastapi import Request
from fastapi.responses import JSONResponse

class ProviderError(Exception):
    def __init__(self, code: str, message: str, retryable: bool = False):
        self.code, self.message, self.retryable = code, message, retryable
        super().__init__(message)

class JudgeOutputError(Exception):
    pass

logger = logging.getLogger("ai_trust_suite")

def request_id(request: Request) -> str:
    return getattr(request.state, "request_id", None) or str(uuid.uuid4())

def error_response(request: Request, status: int, code: str, message: str):
    return JSONResponse(status_code=status, content={"error":{"code":code,"message":message,"request_id":request_id(request)}})
