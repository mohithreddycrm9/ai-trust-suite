import json
from uuid import UUID
from .models import AuditEvent

async def audit(db, org_id:UUID, actor_user_id:UUID, event_type:str, entity_type:str, entity_id:str, metadata=None):
    db.add(AuditEvent(organization_id=org_id,actor_user_id=actor_user_id,event_type=event_type,entity_type=entity_type,entity_id=entity_id,metadata_json=json.dumps(metadata or {},separators=(",",":"))))
