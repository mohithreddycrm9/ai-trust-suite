# USD per 1M tokens, checked against provider-published pricing on 2026-09-29.
# Only exact model IDs below are priced. Unknown/other IDs remain explicitly unknown.
PRICING = {
    "openai": {
        "gpt-5.6-sol": (4.00, 20.00),
        "gpt-5.6-terra": (2.00, 12.00),
        "gpt-5.6-luna": (0.20, 1.20),
    },
    "anthropic": {
        "claude-sonnet-5.5": (2.00, 10.00),
        "claude-opus-5.5": (4.00, 20.00),
        "claude-fable-5-1": (10.00, 50.00),
    },
    "gemini": {
        "gemini-3.5-flash": (1.50, 9.00),
        "gemini-3.5-flash-lite": (0.30, 2.50),
        "gemini-3-flash-preview": (0.50, 3.00),
    },
    "ollama": {},  # Local execution is not charged by AI Trust Suite.
}

def estimate_cost(provider, model, input_tokens, output_tokens):
    if input_tokens is None or output_tokens is None:
        return None, "unknown"
    rates=PRICING.get(provider,{}).get(model)
    if not rates:
        return None,"unknown"
    return input_tokens/1_000_000*rates[0] + output_tokens/1_000_000*rates[1],"estimated"
