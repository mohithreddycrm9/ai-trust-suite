from datetime import datetime, timezone
from uuid import UUID
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from .models import ModelConnection
from .security import encrypt_secret,decrypt_secret
from .providers.registry import provider_for
from .providers.base import GenerationRequest
from .errors import ProviderError

async def create_model(db:AsyncSession,org_id:UUID,body):
    x=ModelConnection(organization_id=org_id,name=body.name,provider=body.provider,model=body.model,encrypted_api_key=encrypt_secret(body.api_key) if body.api_key else None,base_url=body.base_url)
    db.add(x);await db.flush();return x

async def get_scoped_model(db,org_id,model_id):
    return (await db.execute(select(ModelConnection).where(ModelConnection.id==model_id,ModelConnection.organization_id==org_id))).scalar_one_or_none()

async def test_model_connection(x):
    secret=decrypt_secret(x.encrypted_api_key) if x.encrypted_api_key else None
    p=provider_for(x.provider,x.model,secret,x.base_url)
    try:
        await p.generate(GenerationRequest(prompt="Reply with OK.",temperature=0,max_tokens=8))
        x.health_status="healthy";x.last_success_at=datetime.now(timezone.utc);x.last_error=None
    except ProviderError as exc:
        x.health_status="error";x.last_error=exc.code;raise
