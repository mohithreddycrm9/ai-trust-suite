import json
from pydantic import ValidationError
from .schemas import BlindJudgeResult
from ..errors import JudgeOutputError

def parse_judge_output(text: str) -> BlindJudgeResult:
    cleaned=text.strip()
    if cleaned.startswith("```"):
        lines=cleaned.splitlines()
        if lines and lines[0].startswith("```"): lines=lines[1:]
        if lines and lines[-1].strip()=="```": lines=lines[:-1]
        cleaned="\n".join(lines).strip()
        if cleaned.lower().startswith("json"):
            cleaned=cleaned[4:].strip()
    try:
        payload=json.loads(cleaned)
        return BlindJudgeResult.model_validate(payload)
    except (json.JSONDecodeError,ValidationError) as exc:
        raise JudgeOutputError("Judge returned invalid JSON or invalid six-dimension scores") from exc
