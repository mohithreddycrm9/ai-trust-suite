CRITERIA=("accuracy","honesty","safety","relevance","clarity","instruction_following")
