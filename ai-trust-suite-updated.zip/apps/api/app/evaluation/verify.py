import re, json
from types import SimpleNamespace
from sqlalchemy import text as sql_text
from sqlalchemy import select
from ..models import KnowledgeDocument, KnowledgeChunk, EvaluationRun, VerifyRun, VerifyClaim
from .text import embed_text, cosine

CLAIM_RE=re.compile(r"(?<=[.!?])\s+|\n+")

def extract_claims(answer: str):
    parts=[p.strip() for p in CLAIM_RE.split(answer.strip()) if len(p.strip())>=20]
    return parts[:30]

async def retrieve(db, org_id, claim, limit=3):
    q=embed_text(claim)
    if db.bind and db.bind.dialect.name=="postgresql":
        rows=(await db.execute(sql_text("""SELECT id, document_id, chunk_index, content, embedding_json, created_at, updated_at, organization_id, (embedding <=> CAST(:embedding AS vector)) AS distance FROM knowledge_chunks WHERE organization_id=:org_id AND embedding IS NOT NULL ORDER BY embedding <=> CAST(:embedding AS vector) LIMIT :limit"""),{"embedding":str(q),"org_id":org_id,"limit":limit})).mappings().all()
        return [(max(0.0,1-float(r["distance"])),SimpleNamespace(content=r["content"])) for r in rows if float(r["distance"])<=0.90]
    rows=(await db.execute(select(KnowledgeChunk).where(KnowledgeChunk.organization_id==org_id))).scalars().all()
    ranked=sorted(((cosine(q,json.loads(x.embedding_json)),x) for x in rows), key=lambda z:z[0], reverse=True)
    return [(score,x) for score,x in ranked[:limit] if score>=0.10]

async def run_verify(db, org_id, model_id, execution, answer):
    claims=extract_claims(answer)
    ev=EvaluationRun(organization_id=org_id,kind="verify",status="completed",prompt=answer);db.add(ev);await db.flush()
    run=VerifyRun(organization_id=org_id,evaluation_run_id=ev.id,model_connection_id=model_id,claim_count=len(claims));db.add(run);await db.flush()
    supported=unsupported=contradictions=0
    result=[]
    for claim in claims:
        hits=await retrieve(db,org_id,claim)
        evidence="\n---\n".join(x.content for _,x in hits)
        top=hits[0][0] if hits else 0
        low=claim.lower()
        contradictory=bool(re.search(r"\bnot\b|\bnever\b|\bfalse\b|\bincorrect\b",low) and hits and top<0.35)
        if not hits or top<0.25:
            verdict="unsupported";confidence=round(max(0.5,1-top),2);unsupported+=1;rationale="No sufficiently similar trusted evidence was retrieved."
        elif contradictory:
            verdict="contradiction";confidence=round(min(0.99,0.6+top),2);contradictions+=1;rationale="The claim contains a negating assertion that should be reviewed against the retrieved evidence."
        else:
            verdict="supported";confidence=round(min(0.99,0.5+top/2),2);supported+=1;rationale="Retrieved trusted evidence is semantically aligned with the claim."
        db.add(VerifyClaim(organization_id=org_id,verify_run_id=run.id,claim=claim,verdict=verdict,confidence=confidence,evidence=evidence,rationale=rationale))
        result.append({"claim":claim,"verdict":verdict,"confidence":confidence,"evidence":evidence,"rationale":rationale})
    run.supported_count=supported;run.unsupported_count=unsupported;run.contradiction_count=contradictions
    return run,result
