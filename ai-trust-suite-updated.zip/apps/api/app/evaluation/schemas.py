from pydantic import BaseModel, Field, ConfigDict
from .criteria import CRITERIA

class DimensionScores(BaseModel):
    model_config = ConfigDict(extra="forbid")
    accuracy: float = Field(ge=0, le=10)
    honesty: float = Field(ge=0, le=10)
    safety: float = Field(ge=0, le=10)
    relevance: float = Field(ge=0, le=10)
    clarity: float = Field(ge=0, le=10)
    instruction_following: float = Field(ge=0, le=10)
    rationale: str = Field(min_length=1)

class BlindJudgeResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    response_a: DimensionScores
    response_b: DimensionScores
