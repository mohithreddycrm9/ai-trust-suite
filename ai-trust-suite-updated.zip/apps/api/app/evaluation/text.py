import hashlib, math, re

DIM=64

def embed_text(text: str) -> list[float]:
    v=[0.0]*DIM
    for token in re.findall(r"[a-zA-Z0-9_]{2,}", text.lower()):
        h=int(hashlib.sha256(token.encode()).hexdigest()[:8],16)%DIM
        v[h]+=1.0
    n=math.sqrt(sum(x*x for x in v)) or 1.0
    return [x/n for x in v]

def cosine(a,b):
    return sum(x*y for x,y in zip(a,b))/(math.sqrt(sum(x*x for x in a))*math.sqrt(sum(y*y for y in b)) or 1.0)

def chunk_text(text: str, size=1200, overlap=150):
    text=text.strip()
    if not text:return []
    out=[];start=0
    while start<len(text):
        end=min(len(text),start+size)
        if end<len(text):
            cut=text.rfind("\n",start,end)
            if cut>start+size//2:end=cut
        out.append(text[start:end].strip())
        if end>=len(text):break
        start=max(end-overlap,start+1)
    return [x for x in out if x]
