from logging.config import fileConfig
from alembic import context
from sqlalchemy import pool
from sqlalchemy.ext.asyncio import async_engine_from_config
from app.db import Base
from app import models
from app.config import settings

config=context.config
config.set_main_option("sqlalchemy.url",settings.database_url)
if config.config_file_name:fileConfig(config.config_file_name)
target_metadata=Base.metadata

def run_migrations_offline():
    context.configure(url=settings.database_url,target_metadata=target_metadata,literal_binds=True,compare_type=True)
    with context.begin_transaction():context.run_migrations()

async def run_async():
    connectable=async_engine_from_config(config.get_section(config.config_ini_section,{}),prefix="sqlalchemy.",poolclass=pool.NullPool)
    async with connectable.connect() as connection:
        await connection.run_sync(lambda c: context.configure(connection=c,target_metadata=target_metadata,compare_type=True))
        await connection.run_sync(lambda c: context.run_migrations())
    await connectable.dispose()

def run_migrations_online():
    import asyncio;asyncio.run(run_async())

if context.is_offline_mode():run_migrations_offline()
else:run_migrations_online()
