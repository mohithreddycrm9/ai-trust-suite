# AI Trust Suite

AI Trust Suite is a multi-tenant SaaS foundation for testing, verifying and securing AI systems.

## Current modules

- **Arena** — blind randomized model comparison with six trust dimensions.
- **Verify** — trusted-document ingestion, chunking/indexing, claim extraction and evidence-backed verdicts.
- **Test Lab** — repeatable accuracy, safety and robustness test packs with persistent results.
- **Secure** — adversarial prompt-injection, tool-output injection and data-exfiltration probes.
- **Models** — server-side encrypted BYOM connections for OpenAI, Anthropic, Gemini and Ollama.

## Local run

1. Create the environment file:

```bash
cp .env.example .env
```

2. Generate a Fernet key:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Put the generated value into `ENCRYPTION_KEY` in `.env`. Generate a separate random JWT secret, for example:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Put that value into `JWT_SECRET`.

3. Start the stack:

```bash
docker compose up --build
```

The API container runs `alembic upgrade head` before starting FastAPI. The first migration enables the `vector` extension on the pgvector Postgres image.

- Web: http://localhost:3000
- API: http://localhost:8000
- API docs: http://localhost:8000/docs

## Security notes

- API keys are encrypted at rest and are write-only through the API.
- Authentication uses an httpOnly session cookie plus a CSRF cookie/header pair.
- Every data query is organization-scoped.
- Provider prompts and secrets are not logged by default.
- `base_url` is DNS-resolved and private/loopback/link-local destinations are blocked, except explicitly allowlisted Ollama endpoints.
- Provider errors are normalized and returned with request IDs.
- Pricing is exact-model only; unknown model pricing remains `unknown` rather than being guessed.

## Testing

The API test suite uses mocked provider HTTP calls and does not make paid API calls:

```bash
cd apps/api
pytest -q
```

The repository intentionally ships **`.env.example` only**. Never commit a real `.env`, API keys, JWT secrets, or Fernet keys.
